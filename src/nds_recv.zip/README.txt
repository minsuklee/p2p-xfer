﻿nds_recv.nds
   relay를 거쳐서, 수신을 하는 nintendo 쪽 프로그램
   
build by devkitpro 1.5.3

==> p2p-xfer의 NDS client 버전

AP, IP Address ==> Hardcoded (by 외부 프로그램)
Target Address, Port ==> Hardcoded (in Source)

UserID ==> Network Configuration에서 추출
           Ethernet 끝 3 바이트, IP 최하위 주소
		   
명령 예 (sender 쪽)
   $(PATH)send_r sample.nds CF:E7:11:101 113.198.74.220 110 v
    = sample.nds    	  - NDS 쪽으로 download 하려는 파일
	= CF:E7:11:101  	  - 닌텐도의 nds_recv.nds 프로그램이 출력한 UserID
	= 113.198.74.220 110  - IP address, Port number
	= v			 		  - verbose mode
	