 /*
  *  p2p-xfer.c
  *
  *  p2p-relay based file tranfer / Nintendo
  *
  *  Copyright (C) 2013, Minsuk Lee (minsuk@hansug.ac.kr)
  *  All rights reserved.
  *  This software is under BSD license. see LICENSE.txt
  *
  *  2009-12-27  Created
  *  2013-07-15  using p2p relay 
  *  2013-07-17  Nintendo DS wifi version 
  */ 

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <errno.h>
#include <ctype.h>

#include <nds.h>
#include <nds/arm9/console.h>
#include <dswifi9.h>
#include <nds/ndstypes.h>
#include <fat.h>

#define VERSION_STR1    "NDS Download via Relay v0.9\n"
#define VERSION_STR2    "(c) Copyright 2013, Minsuk Lee\n"

// Protocol Description

// 0. connect to relay
//    send type(T-receiver, C-sender) and user-id, $
//    sender receive 'O' if receiver is read on user-id
// 1. SENDER -> RECEIVER : FILE HEADER (48B)
// 2. RECEIVER -> SENDER : 'O'
// 3. SENDER -> RECEIVER : File Data (XXX Bytes)
// 4. SENDER -> RECEIVER : CHECKSUM (16B)
// 5. RECEIVER -> SENDER : 'O'
// 6. close connection with relay

// File Transfer protocol ---------------------------------------------

#define MAX_FILE_SIZE   (2 * 1024 * 1024)    // 2GB int type limited

#define MAX_FILE_NAME_LEN       32
#define MAX_FILE_LENGTH_LEN     16
#define CHECKSUM_LEN            16

struct header {
    char filename[MAX_FILE_NAME_LEN];       // MAX 32 byte ASCIZ file name
    char filelength[MAX_FILE_LENGTH_LEN];   // ASCIZ file length
};
static struct header FHeader;
#define HEADER_SIZE sizeof(struct header)

#define RESP_CODE_LEN   1
// Response Code definition
// 'O' : OK - No Error
// 'X' : Not OK - Error

static int data_socket;

#define BUF_SIZE        2048
static char BUF[BUF_SIZE];

static char ssid[MAX_FILE_NAME_LEN];
static char relay[MAX_FILE_NAME_LEN];
static char userid[MAX_FILE_NAME_LEN];
static int port = 110;

#define CFG_FILE "DOWNLOAD.CFG"

static void
read_conf(void)
{
    FILE *fp;
    int i;

    if ((fp = fopen(CFG_FILE, "r")) == NULL) {
        printf("%s not found.\n", CFG_FILE);
        printf("Use Firmware/Default Setting\n");
        return;
    }
    printf("Reading %s\n", CFG_FILE);
    while (!feof(fp)) {
        if (fgets(BUF, BUF_SIZE, fp) == NULL)
            break;
        for (i = strlen(BUF); i > 0; i--)
           if (isspace((int)BUF[i-1]))   // Cut trailing white spaces
               BUF[i-1] = 0;
           else
               break;
        if ((BUF[0] == '#') || (strlen(BUF) < 1))
            continue;
        printf(" '%s'\n", BUF);
        if (BUF[strlen(BUF) - 1] == '=')
            continue;
        if (!strnicmp(BUF, "SSID=", 5)) {
            strcpy(ssid, BUF + 5);
            continue;
        }
        if (!strnicmp(BUF, "RELAY=", 6)) {
            strcpy(relay, BUF + 6);
            continue;
        }
        if (!strnicmp(BUF, "PORT=", 5)) {
            if (sscanf(BUF + 5, "%d", &port) != 1)
                printf("Invalid port number\n");
            continue;
        }
        if (!strnicmp(BUF, "USERID=", 7)) {
            strcpy(userid, BUF + 7);
            continue;
        }
    }
    printf("-----------------\n");
    fclose(fp);
}

static int
init_wifi(void)
{
    struct in_addr MyIP, gateway, mask, dns1, dns2;
	unsigned char EADDR[6];
    int i;

    printf("AP %s ... ", *ssid ? ssid: "(Firmware)");
    if (Wifi_InitDefault(*ssid ? 0 : WFC_CONNECT) == 0) {
cerr:   printf("FAILED !!\n");
        return -1;
    }
    if (*ssid) {
        Wifi_AccessPoint apdata;
		int wifiStatus = ASSOCSTATUS_DISCONNECTED;

        memset(&apdata, 0, sizeof(apdata));
        strcpy(apdata.ssid, ssid);
        apdata.ssid_len = strlen(ssid);

		Wifi_SetIP(0,0,0,0,0);	
        Wifi_ConnectAP(&apdata, 0, 0, NULL); // no WEP
		while (wifiStatus != ASSOCSTATUS_ASSOCIATED) {
			wifiStatus = Wifi_AssocStatus(); // check status
			if (wifiStatus == ASSOCSTATUS_CANNOTCONNECT)
                goto cerr;
			swiWaitForVBlank();
		}
    } 
    printf("OK\n"); // Mark that WIFI is available

    printf("MAC   : ");
    Wifi_GetData(WIFIGETDATA_MACADDRESS, 6, EADDR);
    for (i = 0; i < 6; i++) {
        printf("%02X", EADDR[i]);
        if (i < 5)
            printf(":");
    }
    printf("\n");

    /// COPY MAC ADDR TO USERID
    
    MyIP = Wifi_GetIPInfo(&gateway, &mask, &dns1, &dns2);
    printf("IP    : %s\n", inet_ntoa(MyIP));

	if (*userid == 0)
        sprintf(userid, "%02X:%02X:%02X:%03d",
            EADDR[3], EADDR[4], EADDR[5], (int)(MyIP.s_addr) >> 24);
	
    return 0;
}

static int
send_data(char *buf, int len)
{
    int size, count = len;

    while (count) {
        if ((size = send(data_socket, buf, count, 0)) <= 0) {
            fprintf(stderr, "TCP Send Error\n");
            return -1;  // Error
        }
        buf += size;
        count -= size;
    }
    return len;
}

static int
recv_data(char *buf, int count)
{
    int size, tread = 0;

    while (count) {
        if ((size = recv(data_socket, buf, count, 0)) < 0) {
            fprintf(stderr, "TCP Recv Error\n");
            return -1;  // Error
        }
        if (size == 0)
            break;
        buf += size;
        count -= size;
        tread += size;
    }
    return tread;
}

static void
disconnect(void)
{
    close(data_socket);
//  Wifi_DisconnectAP();
//  Wifi_DisableWifi();
}

static int
connect_relay(void)
{
    struct sockaddr_in relay_sin;
    unsigned long haddr;

    //strcpy(relay, "fs.hansung.ac.kr");

    if ((data_socket = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("socket");
        return -1;
    }

    printf("Relay : %s\n", relay);
    printf("Port  : %d\n", port);

    if ((haddr = inet_addr(relay)) == 0xffffffffL) {
        struct hostent *hp;
        if ((hp = gethostbyname(relay)) == NULL) {
            printf("\nCan resolve Relay Name\n");
			return -1;
		}
		haddr= *(unsigned long *)(hp->h_addr_list[0]);
	}
        
    relay_sin.sin_family = AF_INET;
    relay_sin.sin_addr.s_addr = haddr;
    relay_sin.sin_port = htons(port);

    if (connect(data_socket, (struct sockaddr *)&relay_sin, sizeof(relay_sin)) < 0) {
        printf("Failed to Connect\n");
        disconnect();
        return -1;
    }
    sprintf(BUF, "T%s$", userid); // Wait File Transfer Connection

    send_data(BUF, strlen(BUF));
    printf("UserID: %s\n", userid);
    printf("... Wait for sender ...\n");
    return 0;
}

int
main()
{
    FILE *fp = NULL;
    int filesize;
    int size, ret, i, checksum;

	consoleDemoInit();
	fatInitDefault();

    printf("%s%s", VERSION_STR1, VERSION_STR2);

    strcpy(relay, "fs.hansung.ac.kr");
    read_conf();
    
    if (init_wifi()) {
        printf("WIFI Initialize Error\n");
        goto leave0;
    }

    if (connect_relay() < 0)
        goto leave0;

    // receive Header, put 'O', receive Data, Checkum, put 'O'
    if (recv_data((char *)&FHeader, HEADER_SIZE) != HEADER_SIZE) {
        printf("Failed to Receive Header\n");
        goto leave1;
    }
    printf("Header Received OK\n");

    if (sscanf(FHeader.filelength, "%d", &filesize) != 1) {
        fprintf(stderr, "Invalid Header Format\n");
        goto leave2;
    }
    if ((filesize <= 0) || (filesize > MAX_FILE_SIZE)) {
        fprintf(stderr, "Invalid Length : %dB\n", filesize);
        goto leave2;
    }
    printf("FILE  : %s\n", FHeader.filename);
    printf("Size  : %d Bytes\n", filesize);

    if ((fp = fopen(FHeader.filename, "wb")) == NULL) {
        fprintf(stderr, "File Open Error\n");
        goto leave2;
    }
    send_data("O", RESP_CODE_LEN);

    size = filesize;
    checksum = 0;
    while (size > 0) {
        if ((ret = recv_data(BUF, (size < BUF_SIZE) ? size : BUF_SIZE)) <= 0) {
            fprintf(stderr, "Data Receive Error\n");
            goto leave1;
        }
        size -= ret;
        if (ret != fwrite(BUF, 1, ret, fp)) {
            fprintf(stderr, "File Write Error\n");
            goto leave2;
        }
        for (i = 0; i < ret; i++)
            checksum += BUF[i];
        printf("\r%dB Left ", size);
    }
    printf("\rFile Data Received\n");

    if ((ret = recv_data(BUF, CHECKSUM_LEN)) != CHECKSUM_LEN)
        goto sum_e;
    if (sscanf((char *)BUF, "%d", &ret) != 1)
        goto sum_e;
    if (ret != checksum) {
sum_e:  fprintf(stderr, "Checksum Error\n");
leave2: send_data("X", RESP_CODE_LEN);
        goto leave1;
    }
    send_data("O", RESP_CODE_LEN);
    printf("Checksum OK\n");
    printf("File Download ... Done\n");
leave1:
    disconnect();
leave0:
    if (fp)
        fclose(fp);
    printf("\n-- Press Power OFF and ON --\n");
    while (!(keysCurrent() & 0xFFFF))
        ;
    exit(0);
    return 0;
}
