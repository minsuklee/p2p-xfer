 /*
  *  p2p-xfer.c
  *
  *  p2p-relay based file tranfer / Nintendo
  *
  *  Copyright (C) 2013,  Minsuk Lee (minsuk@hansug.ac.kr)
  *  All rights reserved.
  *  This software is under BSD license. see LICENSE.txt
  *
  *  2009-12-27  Created
  *  2013-07-15  using p2p relay 
  *  2013-07-17  Nintendo DS wifi version 
  */ 

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <errno.h>

#include <nds.h>
#include <nds/arm9/console.h>
#include <dswifi9.h>
#include <nds/ndstypes.h>
#include <fat.h>

#define VERSION_STR1    "Downloader via Relay v0.1-NDSL\n"
#define VERSION_STR2    "(c) Copyright 2013, Minsuk Lee\n"

// Protocol Description

// 0. connect to relay
//    send type(T-receiver, C-sender) and user-id, $
//    sender receive 'O' if receiver is read on user-id
// 1. SENDER -> RECEIVER : FILE HEADER (48B)
// 2. RECEIVER -> SENDER : 'O'
// 3. SENDER -> RECEIVER : File Data (XXX Bytes)
// 4. SENDER -> RECEIVER : CHECKSUM (16B)
// 5. RECEIVER -> SENDER : 'O'
// 6. close connection with relay

// File Transfer protocol ---------------------------------------------

#define MAX_FILE_SIZE   (2 * 1024 * 1024)    // 2GB int type limited

#define MAX_FILE_NAME_LEN       32
#define MAX_FILE_LENGTH_LEN     16
#define CHECKSUM_LEN            16

struct header {
    char filename[MAX_FILE_NAME_LEN];       // MAX 32 byte ASCIZ file name
    char filelength[MAX_FILE_LENGTH_LEN];   // ASCIZ file length
};
struct header FHeader;
#define HEADER_SIZE sizeof(struct header)

#define RESP_CODE_LEN   1
// Response Code definition
// 'O' : OK - No Error
// 'X' : Not OK - Error

int data_socket;

#define BUF_SIZE        2048
char BUF[BUF_SIZE];

char *target = "113.198.74.220";
char userid[MAX_FILE_NAME_LEN];

int port = 110;

int
wifi_init(void)
{
    struct in_addr MyIP, gateway, mask, dns1, dns2;
    int ret, i;
	unsigned char BUF[6];

	// Hard-Code
	// For AP, IP Address
	
    printf("Finding AP...");
    ret = Wifi_InitDefault(WFC_CONNECT);
    if(ret == 0) {
        printf("\nWIFI:Initialize Failure\n");
        return -1;
    }
    printf(" Done\n"); // Mark that WIFI is available

    printf("MAC   : ");
    Wifi_GetData(WIFIGETDATA_MACADDRESS, 6, BUF);
    for (i = 0; i < 6; i++) {
        printf("%02X", BUF[i]);
        if (i < 5)
            printf(":");
    }
    printf("\n");

    /// COPY MAC ADDR TO USERID
    
    MyIP = Wifi_GetIPInfo(&gateway, &mask, &dns1, &dns2);
    printf("IP    : %s\n", inet_ntoa(MyIP));

	sprintf(userid, "%02X:%02X:%02X:%03d",
        BUF[3], BUF[4], BUF[5], (int)(MyIP.s_addr) >> 24);
	
    return 0;
}

int
send_data(char *buf, int len)
{
    int size, count = len;

    while (count) {
        if ((size = send(data_socket, buf, count, 0)) <= 0) {
            fprintf(stderr, "TCP Send Error\n");
            return -1;  // Error
        }
        buf += size;
        count -= size;
    }
    return len;
}

int
recv_data(char *buf, int count)
{
    int size, tread = 0;

    while (count) {
        if ((size = recv(data_socket, buf, count, 0)) < 0) {
            fprintf(stderr, "TCP Recv Error\n");
            return -1;  // Error
        }
        if (size == 0)
            break;
        buf += size;
        count -= size;
        tread += size;
    }
    return tread;
}

void
disconnect()
{
    close(data_socket);
//    Wifi_DisconnectAP();
//    Wifi_DisableWifi();
}

int
connect_relay(char *userid)
{
    struct sockaddr_in relay_sin;

    if ((data_socket = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("socket");
        return -1;
    }

    printf("Relay : %s:%d\n", target, port);
    relay_sin.sin_family = AF_INET;
    relay_sin.sin_addr.s_addr = inet_addr(target);
    relay_sin.sin_port = htons(port);

    if (connect(data_socket, (struct sockaddr *)&relay_sin, sizeof(relay_sin)) < 0) {
        printf("Failed to Connect\n");
        disconnect();
        return -1;
    }
    sprintf(BUF, "T%s$", userid); // Wait File Transfer Connection

    send_data(BUF, strlen(BUF));
    printf("UserID: %s\n", userid);
    printf("... Wait for sender ...\n");
    return 0;
}

int
main()
{
    FILE *fp = NULL;
    int filesize;
    int size, ret, i, checksum;

	consoleDemoInit();
	fatInitDefault();

    printf("%s%s", VERSION_STR1, VERSION_STR2);

    if (wifi_init()) {
        printf("WIFI Initialize Error\n");
        return -1;
    }

    if (connect_relay(userid) < 0) {
        goto leave0;
    }

    // receive Header, put 'O', receive Data, Checkum, put 'O'
    if (recv_data((char *)&FHeader, HEADER_SIZE) != HEADER_SIZE) {
        printf("Failed to Receive Header\n");
        goto leave1;
    }
    printf("Header Received OK\n");

    if (sscanf(FHeader.filelength, "%d", &filesize) != 1) {
        fprintf(stderr, "Invalid Header Format\n");
        goto leave2;
    }
    if ((filesize <= 0) || (filesize > MAX_FILE_SIZE)) {
        fprintf(stderr, "Invalid Length : %dB\n", filesize);
        goto leave2;
    }
    printf("FILE  : %s\n", FHeader.filename);
    printf("Size  : %d Bytes\n", filesize);

    if ((fp = fopen(FHeader.filename, "wb")) == NULL) {
        fprintf(stderr, "File Open Error\n");
        goto leave2;
    }
    send_data("O", RESP_CODE_LEN);

    size = filesize;
    checksum = 0;
    while (size > 0) {
        if ((ret = recv_data(BUF, (size < BUF_SIZE) ? size : BUF_SIZE)) <= 0) {
            fprintf(stderr, "Data Receive Error\n");
            goto leave1;
        }
        size -= ret;
        if (ret != fwrite(BUF, 1, ret, fp)) {
            fprintf(stderr, "File Write Error\n");
            goto leave2;
        }
        for (i = 0; i < ret; i++)
            checksum += BUF[i];
        printf("\r%dB Left ", size);
    }
    printf("\rFile Data Received\n");

    if ((ret = recv_data(BUF, CHECKSUM_LEN)) != CHECKSUM_LEN)
        goto sum_e;
    if (sscanf((char *)BUF, "%d", &ret) != 1)
        goto sum_e;
    if (ret != checksum) {
sum_e:      fprintf(stderr, "Checksum Error\n");
leave2:     send_data("X", RESP_CODE_LEN);
        goto leave1;
    }
    send_data("O", RESP_CODE_LEN);
    printf("Checksum OK ... Done\n");
leave1:
    disconnect();
leave0:
    if (fp)
        fclose(fp);
    printf("\n-- Press Anykey to Power OFF --\n");
    while (!(keysCurrent() & 0xFFFF))
        ;
    exit(0);
    return 0;
}
